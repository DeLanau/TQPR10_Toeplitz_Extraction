# Föreläsning 2

Föreläsningen kretsar kring hur man samlar in information från bra källor, samt
hur man kan söka fram källor som är relevanta. Jag antar att det finns någon mån
av källkritik inblandad någonstans här i smeten. Ren spekulation, dock.
