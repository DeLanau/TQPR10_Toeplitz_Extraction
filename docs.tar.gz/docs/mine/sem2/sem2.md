# Seminar 1

1. Vad är det studerade problemet och varför är det viktigt? Hur motiveras det?
2. Väcker introduktionen läsarens intresse? På vilket sätt? Hur skulle
   introduktionen kunna göras mer intressant?
3. Är frågeställningen tydligt formulerad? Kan frågeställningen förbättras (hur
   och avseende vad, i så fall)?
4. Går frågeställningen att besvara på ett rimligt och entydigt sätt?

## pieka505, yili533

1. Frågeställningen kretsar kring att exkludera en central server i en
   molntjänst för att låta klienter kommunicera direkt med Amazon S3 på ett
   säkert sätt. Det beskrivs som att servern får en relativt tung belastning,
   och att detta kan vara en flaskhals, och artikeln skall undersöka huruvida
   direkt kontakt med Amazon S3 kan ge bättre prestanda och nätverkseffektivitet
   samt om säkerheten kan förstärkas för att uppnå en liknande säkerhetsstandard
   som en central server kan erbjuda.
2. Jag hade gärna sett lite bakgrund med något mer konkreta siffror för att
   påvisa de ineffektiviteter som det härleds till i introduktionen. Detta hade
   nog väckt lite mer intresse, men det kanske är subjektivt. Det finns
   potentiellt annan forskning att referera till.
3. Det finns tre frågor varav två går att besvara med ren fakta. Den sista
   frågan, den kring säkerheten, kanske kan behöva lite mer riktning. Annars
   behöver metoden nog utveckla hur man kvantifierbart jämför säkerhet på någon
   slags objektiv skala.
4. Utöver kommentaren kring säkerhetsfrågan tror jag att samtliga frågor går att
   besvara på ett eller annat sätt utan några problem.

## danka340

1. Artikeln kretsar kring hur det är möjligt att öka adoptionsnivån av nya
   implementationer i SaaS-system. Det beskrivs med via en referens att
   UX-design kan spela en stor roll i hur pass mycket användare kan vara villiga
   att interagera med ny funktionalitet, och denna uppsats verkar ha som mål att
   bekräfta det med en studie av ett befintligt system, samt om förändringar i
   applikationens UX kan leda till högre adoptionsnivå av ny funktionalitet.
2. Min uppfattning är att arbetet härleder mycket från den första referensen.
   Skiljer sig detta arbete markant från detta? Eller är detta arbete för att
   påvisa effekterna som denna referens presenterar? Detta är en fråga som
   hindrar mitt intresse en aning.
3. Det finns två konkreta frågeställning. Den första frågan känns aningen
   diffus, då detta kräver att man definierar "user engagement" och hur
   "leveraging customer data" ska göras. Absolut, det kommer säkerligen besvaras
   i metoden, men den frågeställningen känns lite abstrakt. Om den första
   frågeställningen konkretiseras kommer den andra frågeställningen (som är tätt
   knuten till den första) att bli mer konkret också. Men detta kan säkert
   knytas ihop under metoden.
4. Som nämnt ovan, det är lite oklart hur detta ska mätas. Det är aningen lösa
   frågeställningar, så jag skulle gärna se lite mer konkret information om hur
   dessa abstrakta mått ska mätas innan det går att avgöra huruvida det går att
   faktiskt besvara frågorna entydligt.

## claen776, addsa705

1. Frågeställningen kretsar mest av allt kring latency och batterieffektivitet
   för Bluteooth-sändare, och hur väl dessa kan användas för tidsmätning inom
   extremsport. Medan introduktionen verkar gå in en del på metodiken så kan jag
   förstå att viss del av den informationen kan behövas, men det är något värt
   att fundera på.
2. Det är en väldigt intressant frågeställning, men jag känner att den dyker in
   en del på metodiken. Medan jag finner metodiken intressant så känns det
   spontant som att detta kan komma att dupliceras i nästa sektion, så det kan
   vara värt att plocka bort fokus från hur detta ska genomföras och fokusera
   mer på bakgrunden.
3. Frågeställningarna i denna artikel är väl formulerade och mätbara, och jag
   ser ingenting som skulle vara diffust kring dem. Dock tror jag att den första
   frågan skulle kunna brytas ned lite mer, genom att specificera hur man avgör
   om detta är ett rimligt alternativ. Det skrivs lite om det i löptexten, men
   kan med fördel konkretiseras vid den faktiska frågan också.
4. Så länge som den första frågan kan göras mer konkret mätbar (mer än bara ja
   eller nej) så ser jag absolut inga hinder för att kunna entydigt besvara
   frågorna.

## aldba746, filin764

1. Bakgrunden är kanske lite kort, och skulle eventuellt behöva utvecklas lite
   mer. Kan man peka ut exempel på vilka utmaningar som man kan stöta på? Finns
   det annan forskning som siktar på att besvara samma typ av frågeställning som
   man istället kan referera till snarare än att ta upp det själv? Det finns
   vikt och motivation här, men det är i min mening lite för kort för att kunna
   väcka intresse på ett bra sätt, och det känns lite "pang på", i brist på
   bättre ord.
2. Det känns som att introduktionen är så pass kort att det inte riktigt hinns
   med att väcka intresse. Jag skulle vilja se lite mer information om systemet
   de ska arbeta på, som ett konkret exempel, så att man som läsare kan få lite
   mer kött på benen inför frågeställningen.
3. Frågeställningen i denna artikel är då inte en direkt fråga, utan snarare en
   analys. En analys kan mynna ut i en konkret fråga, men denna frågeställning
   upplever jag behöver vara lite mer mätbar, alternativt mer konkret. En analys
   kan dock vara en fullt rimlig sak att göra, men även då kan det nog
   konkretiseras mer vad analysen faktiskt kommer att titta på -- som det är
   skrivet nu önskar i alla fall jag lite mer information.
4. Som nämnt mynnar en analys inte ut i ett mätbart, konkret resultat, så det är
   svårt att säga. Resultatet kommer till väldigt stor del bero på hur arbetet
   faktiskt går, så i introduktionen är det svårt (om inte omöjligt) att veta om
   frågan går att enhälligt besvara.

## simlu515

1. Frågeställningen är, utan någon tvekan, en viktig en. Säkerhet är a och o
   inom moderna applikationer, och jag upplever att introduktionen understryker
   detta. Potentiellt kan det vara lite väl brett uttryckt i introduktionen, då
   jag upplever att det talas om säkerhetsbrister väldigt allmänt.
2. Det nämns kortfattat att man kan använda "automatiserade verktyg" för att
   hitta och lösa eventuella brister i en applikation. Jag skulle vara väldigt
   intresserad av mer information om dessa -- ska dessa byggas som en del av
   arbetet? Om ja, kommer de då att byggas med OWASPs lista i åtanke? Eller
   används publikt tillgängliga verktyg? Eller hör detta mer hemma i metodiken?
3. Det knyter lite samman till poängen ovan, men frågeställningen lämnar lite
   öppet. Förvisso kanske detta kommer att besvaras mer under metodiken, men i
   och med att det inte tydliggörs huruvida egna verktyg kommer att byggas eller
   om befintliga verktyg kommer att testas (eller om det är något helt annat som
   pågår i metodiken) så finner jag det svårt att veta exakt vad
   frågeställningen kommer att vara.
4. Att mäta effektiviteten av dessa verktyg kommer så klart att behöva
   tydliggöras under metodiken, men jag känner spontant att det behövs lite mer
   konkret information för att kunna avgöra om frågeställningen kan besvaras
   endast utifrån den infromation som finns i introduktionen.
