# Lässeminarie 2

1. Ger teorin intrycket av att författarna är väl insatta i området (motivera)?
2. Hur pass detaljerat beskrivs tidigare forskning och utveckling; svepande
   formuleringar eller detaljerade djupdykningar (motivera)?
3. Hur många källor refererar författarna till i samband med teoristycket?
   Verkar dessa källor vara väl valda och tillförlitliga (motivera)?
4. Har tillräckliga ansträngningar gjorts för att sätta arbetet i en
   vetenskaplig respektive industriell kontext (motivera)?
5. Vad har studien för nyhetsvärde i relation till tidigare forskning och
   utveckling (motivera)? Har teorin en tydlig struktur (motivera)? Är den
   strukturerad enligt viktiga teman baserad på författarens egen analys av
   litteraturgenomgången eller per författare/artikel?

## Artikel 1

1. Det gör den definitivt. Medan det kommer att bemötas i nästa stycke så visar
   författarna på att de har noggrant kontrollerat andra studier för att finna
   relevant arbete, men att mycket av det som de stötte på inte relaterar till
   programmerarnas upplevda effektivitet. De för ett gott argument för vad för
   nytta deras arbete kan bidra med till denna tidigare forskning.
2. Det är många källor som tas upp i teorin, och med denna mängd så får varje
   tämligen lite plats i artikeln. Däremot så påvisar dessa källor att arbetet
   som har gjorts inte relaterar till exakt den domän som de vill forska inom,
   vilket gör att jag personligen anser det bra att de inte går in för djupt på
   dem. Att visa på att annan forskning gjorts på snarliggande områden -- men
   inte det faktiska området artikeln handlar om -- det är i min mening mer än
   tillräckligt.
3. Jag får det till 27 referenser när författarna är inne på relaterade verk,
   vilket lägger den teoretiska grunden för denna artikel. De flesta, om inte
   alla referenserna talar om verk som _inte_ går in på samma sak som de själva
   gör, m.a.o. mäter de eller beskriver produktivitet ur ett annat perspektiv,
   alternativt så beskriver referenserna forskning kring hur effektivitet kan
   förbättras. Personligen känner jag att det kan vara lite i överkant. Absolut
   så bör forskning som är relaterad till detta arbete refereras till, men jag
   känner viss skepsis till hur relevant det är att ta upp så många exempel som
   inte berör den exakta domän som författarna arbetar inom. Det känns som att
   det hade kunnat nyttjas färre referenser som typexempel, eller som mer direkt
   visar på någonting de vill poängtera ut. Mängden referenser är således
   rimlig, men faktumet att de endast känns löst kopplade till arbetet så som
   det hittills bekrivits får mig att känna att referenserna hade kunnat
   användas lite annorlunda till bättre effekt.
4. De visar på genom sina källor att forskning har gjorts ur ett industriellt
   perspektiv, och att denna artikel syftar till att belysa programmerarnas egna
   perspektiv -- alltså mer ur en individualistisk synvinkel mer än någonting
   annat. Detta gör att jag får uppfattningen av att det finns en god kontext
   inom industrin för arbetet, då denna forskning ger andra sidan av det mynt
   som redan studerats.
5. Eftersom artikeln visar så tydligt att forksningen som gjorts är tvärgående
   med deras egen, m.a.o. att det beror programmerares effektivitet ur ett helt
   annat perspektiv, så upplever jag att det är högst relevant och
   nyhetsvärdigt. Sättet som teorin beskrivs på är även logisk, och faller i
   ungefär den följd jag själv kan tänka mig att jag hade ställt frågor om
   befintlig forskning inom ämnet, och det finns en god röd tråd involverad
   genom hela diskussionen. Tematiskt så känner jag även att de har en struktur
   kring vilken typ av forksning som kontrolleras och när i kapitlet. Eftersom
   en referens till annan, tvärgående vetenskap tacklas i taget så upplever jag
   att det är huvudsakligen strukturerat utefter artiklarnas innehåll, vilket
   var trevligt.

## Artikel 2

1. Teorin är mycket djupgående, och definierar konceptet av 'crowdsourcing'
   konkret innan de täcker de nyckelaspekter inom crowdsourcing de anser viktiga
   och relevanta. Överlag fick jag ett gott intryck, men det kändes på vissa
   punkter som att författarna kanske bör ha dragit ned en smula på
   beskrivningens längd på vissa punkter. Hur man gör det utan att förlora
   kontext kan jag inte svara på, men det kanske är en smaksak.
2. Å ena sidan så beskrivs det väl hur de har kommit fram till sina slutsatser
   med den bakgrund som lagts fram, men å andra sidan känns det också som att
   det inte finns mycket detaljer som går att härleda till en unik källa.
   Eftersom det är många källor så får ingen av dem mycket utrymme att
   beskrivas, så medan enskilda källor endast får en ytlig genomgång så blir det
   en djupdykning in i vetenskapen.
3. Jag har säkert räknat med en referens flera gånger, men jag fick det till 72
   unika referenser (med förbehåll att jag mycket möjligt kan ha räknat med
   någon två gånger). Detta är i min mening extremt. Det fanns en mening på elva
   ord med källhänvisning till åtta separata källor (2.2.6), och ett flertal
   ställen där flera meningar i rad hänvisades till en källa. Jag har full
   respekt för att det är viktigt att attributera till rätt källor, men
   någonstans anser jag att det borde få räcka. En specifik instans som kändes
   extra absurd var i sektion 2.2.1 där författarna (löst översatt) hänvisar
   till att en källa fick dem att påminnas av / påminnas om ett citat, som
   hänvisas till i nästföljande källa, vilket för mig känns rent absurt.
   Någonstans vill jag tro att det kan finnas enskilda eller färre källor som
   kan sammanfatta det som de vill uttrycka, och att det inte bör vara
   nödvändigt att lägga till så pass många attributioner. Med det sagt, så
   skummade jag igenom vart dessa källor publicerats (till stor del), och det
   verkar ändå vara publikationer som enligt min uppfattning är tillförlitliga.
   Med tanke på den absurda mängden, och hur pass ofta de dyker upp så känns det
   som att alla källor som har hittats har refererats till, så möjligen kanske
   ett bättre urval bör ha gjorts.
4. Med tanke på att de presenterar en lavin av referenser till böcker,
   forskningsartiklar och allt möjligt annat under teorin, och att dessa
   referenser verkar tala om arbete tätt knutet till denna artikel i ett flertal
   tillfällen, så får jag uppfattningen av att det ställs väl i kontext till
   vetenskaplig relevans. Detta är ju en fallstudie snarare än en artikel som
   menar att utforska någonting helt nytt, så genom att påvisa att det finns
   mycket relevant forskning så befäster det min uppfattning om att det finnsgod
   vetenskaplig relevans.
5. Artikeln är väldigt väl strukturerad, och jag uppskattade enormt hur det var
   upplagt. För fallstudien är det högst relevant att bena ut vad som faktiskt
   innefattas av deras definition av 'crouwdsourcing' i denna kontext, samt att
   de viktiga nyckelaspekterna är väl definierade. Strukturen verkar således
   vara mer utefter författarnas eget tycke, vilket jag anser passa bra här. Jag
   har varit inne på det innan, men det upplevs även (ironiskt nog, med tanke på
   vad jag tyckte om det) som att andelen referenser även indikerar att det
   finns gott nyhetsvärde.

## Artikel 3

1. Enligt mig, ja. Bluetooth är inte min starkaste sida rent tekniskt, så min
   grundläggande förståelse för Bluetooth och BLE (såsom det beskrivs i
   artikeln) var sedan innan låg. Men teorin bakom denna artikel som presenteras
   har en tydlig röd tråd, och den pedagogiska framläggningen rent strukturellt
   samt innehållet i dem ger mig intrycket av att författaren är väl insatt i
   sitt ämne.
2. Med reservation för att många av källorna upprepades och jag således kan ha
   räknat fel fick jag det till tio unika källor i teorin, sektionen för
   relaterat arbete exkluderat. För de relaterade arbeten listas tre referenser
   utöver detta. Många av referenserna hänvisar till specifika detaljer inom
   Apples iOS-ekosystem, och referenserna går direkt till Apples utvecklarsidor.
   Utöver detta finner jag även referenser som hänvisar till
   [bluetooth.com](https://bluetooth.com/), som -- medan jag aldrig hört om den
   tidigare -- verkar vara en sida dedikerad till Bluetooth som teknologi. För
   de övriga referenserna hänvisas det till artiklar som publicerats i IEEE,
   från LiU och en bok. Utöver boken har jag fullt förtroende för källornas
   trovärdighet, och medan jag inte kan kommentera kring boken så bekräftar den
   två tidigare referenser, vilket får mig att ändå tro till källan.
3. Ja. Det är mycket tekniska detaljer som refereras till i artikeln med god
   hänvisning till en förstahandskälla (m.a.o. Apple), samt att de tre
   publicerade artiklar som refereras är tydligt sammankopplade, och alla täcker
   samma ämnesområde med liknande resultat. Dock så kan man undra om det finns
   artiklar som motsäger dessa studiers resultat, men detta är kanske att tänka
   lite väl länge kring det.
4. Absolut. Artikeln går in på djup detalj kring tekniska aspekter som relaterar
   till den exakta tekniken som hela artikelns hjärtefråga kretsar kring. Det
   råder för mig inga tvivel om att det artikeln är placerad väl i kontext för
   industrin och vetenskaplig relevans.
5. I och med att artikeln är från 2014 är det svårt att placera artikelns
   nyhetsvärde i relation till hur vetenskapen såg ut då. Medan jag knappast är
   en expert på Bluetooth eller BLE så är det koncept jag hört talas om till
   viss utsträckning, och ett antal av koncepten har jag viss bekantskap med.
   Det var säkerligen inte lika tydligt eller vanligt under 2014, så det är
   svårt att säga. Däremot verkar det vara tätt knutet till befintlig forskning
   som tas upp i artikeln, och medan applikationen av artikeln är en produkt kan
   vetenskapen fortfarande vara bidragande till framtida, liknande produkter.
   Det finns ett gott genomsyrande tema i artikeln där Bluetooth som teknologi
   täcks noggrant med fokus på de aspekter som är aktuella för artikeln, och
   detta verkar främst vara valt utefter författarens eget perspektiv än något
   annat.
